import { useCountdown } from "hooks/useCountdown";

const PresaleCountDownItem = ({ type, value }) => {
  return (
    <div className="flex-col items-center justify-center countdown-outer">
      <span className="font-Passion-One text-[32px] md:text-[64px] text-white text-center">
        <h2>{value}</h2>
      </span>
      <span className="font-Passion-One text-white items-center text-[12px] md:text-[16px]">
        <p>{type}</p>
      </span>
    </div>
  );
};

const PresaleCountdown = () => {
  const [days, hours, minutes, seconds] = useCountdown(new Date(2022, 10, 10));
  const presaleCountdownItems = [
    { type: "days", value: days },
    { type: "hours", value: hours },
    { type: "minutes", value: minutes },
    { type: "seconds", value: seconds },
  ];
  return (
    <div className="flex-col space-y-[30px]  items-start justify-start my-[40px]">
      <p className="font-Passion-One text-start text-[20px] my-[30px] text-white ">
        presale ends in :
      </p>
      <div className="flex gap-4 items-start justify-start">
        {presaleCountdownItems.map((item, index) => (
          <PresaleCountDownItem
            key={index}
            type={item.type}
            value={item.value}
          />
        ))}
      </div>
    </div>
  );
};

export default PresaleCountdown;
