/* eslint-disable jsx-a11y/anchor-is-valid */
import TopNav from "./components/TopNav";
import Footer from "./components/Footer";
import Play from './components/Play';
import How from "./components/How";
import Presale from "./components/Presale";
import Fort from "./components/Fortrex";
import Roadmap from "./components/Roadmap";
import Team from "./components/Team";
import Hero from "./components/Hero";
import Opponent from "./components/Opponent";

const Home = () => {
  return (
    <div>
       <TopNav />
        <Hero/>
        <Opponent/>  
        <Play/>
        <How/>
        <Presale/>
        <Fort/>
        <Roadmap/>
        <Team/>
        <Footer/>
    </div>
  );
};

export default Home;
