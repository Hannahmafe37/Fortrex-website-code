import React from "react";
import styled from "styled-components";
import   Running  from "../../../assets/images/run.svg";
import   gradient  from "../../../assets/images/gradient.svg";
import  Bnb  from "../../../assets/images/bnb.svg";
import PresaleCountdown from "components/PresaleCountdown";
import {motion} from "framer-motion"
import {textAnimate} from "./Animation"


const Wrapper = styled.div`
    background: url(${Running});
    background-position: bottom bottom;
    background-size: cover;
    background-repeat: no-repeat;
    height: 100vh;
    padding-right:6rem;
    position relative;
    @media (max-width: 1024px){
     padding-right:0rem;
     background:none;
     height:auto;
     }
    }
    .presale-item{
     margin-top: 30vh;

    }
  .project-container{
    display:grid;
    grid-template-columns: repeat(4, 1fr);
    background: rgba(255, 255, 255, 0.02);
    box-shadow: 0px 30px 80px rgba(0, 0, 0, 0.25);
    backdrop-filter: blur(80px);
    border-radius: 8px;
    padding:1rem;

  }
  @media (max-width: 1024px) {
    .presale-container {
      flex-direction: column;
      gap: 38px;
      p,
       {
        text-align: center;
      }
    }
  }
  @media (max-width: 700px){
    .project-container{
        grid-template-columns: repeat(2, 1fr);
      }
    .presale-item{
        margin-top:0vh;
    }
    .item-1{
      border-bottom:1px solid white;
    }
    .item-2{
        border-right:0;
    }
  }
  @media (max-width: 500px) {
    .project-container{
      margin: 0px;
     
    }
   
  }
`;

const Presale = () => {
  return (
    <Wrapper className="mt-[80px]">
      <div className="wrapped-content presale">
        <div className="flex items-center justify-end presale-container">
          <motion.div 
            initial={"offscreen"}
            whileInView={"onscreen"}
            viewport={{once:true, amount:0.5}}
            transition={{staggerChildren:0.5}}
            variants={textAnimate}
            className="flex flex-col space-y-[10px] max-w-[700px] presale-item">
           <h3 className="metrics-header font-Passion-One text-center mid:text-start text-white text-[36px]">Presale Stages</h3>
            <div className="project-container p-[1rem] ">
                <div className="p-[1rem] border-r-[1px] border-[#f5f5f5] item-1">
                    <p className="text-white">Total Supply</p>
                    <h3 className="text-white text-[25px]">10.000.000</h3>
                </div>
                <div className="p-[1rem] border-r-[1px] border-[#f3f3f3] item-1 item-2">
                    <p className=" text-white">30% of supply</p>
                    <h3 className="text-white text-[25px]">3.000.000</h3>
                </div>
                
                <div className="p-[1rem] border-r-[1px] border-white ">
                    <p className="text-white ">Ticker</p>
                    <h3 className="text-white text-start  text-[25px]">MAGG</h3>
                </div>
                <div className="p-[1rem]">
                    <p className="text-white">Start price</p>
                    <h3 className="text-white text-start text-[25px]">-</h3>
                </div>
            </div>
             <div>
              <img src={Bnb} className="mt-[2rem] max-w-[280px]"/>
             </div>
             <PresaleCountdown/>
          </motion.div>
          <img src={Running} className="lg:hidden"/>
          <img src={gradient} className="absolute  right-[-400px]"/>
          
        </div>
      </div>
     
    </Wrapper>
  );
};

export default Presale;
