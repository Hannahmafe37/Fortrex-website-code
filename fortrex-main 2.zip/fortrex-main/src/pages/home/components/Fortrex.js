import React from 'react'
import  Cannons from "assets/images/Cannons.svg";
import {motion} from "framer-motion"
import {textAnimate} from "./Animation"


function Fortrex() {
  return (
       <motion.div 
          initial={"offscreen"}
          whileInView={"onscreen"}
          viewport={{once:true, amount:0.5}}
          transition={{staggerChildren:0.5}}
          className="mt-[80px] pd flex flex-col items-center" >
            <motion.h1
             variants={textAnimate}
            className="text-header md:text-large uppercase leading-none text-white text-center">
             Your fortrex
            </motion.h1>
            <motion.p 
            variants={textAnimate}
            className="text-white text-[14px] max-w-[900px] md:text-[16px] font-zona-semibold text-center">
            An RTS game with deck building and detailed progression system that lets you customize 
            Fortrex to your playstyle. Create a unique deck and destroy your enemies
            </motion.p>
            <motion.div 
               variants={textAnimate}
                className='relative mt-[3rem]'>
                <img src={Cannons} className='max-w-[500px] sm:max-w-[600px] lg:max-w-[900px] xl:max-w-[1350px]'/>
            </motion.div>
           
       </motion.div>
  )
}

export default Fortrex