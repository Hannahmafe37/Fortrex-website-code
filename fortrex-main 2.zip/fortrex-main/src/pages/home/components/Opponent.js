import React from 'react'
import LeafLeft from 'assets/images/leaf-left.svg'
import LeafRight from 'assets/images/leaf-right.svg'
import Star from 'assets/images/star.svg'
import {motion} from "framer-motion"
import {textAnimate} from "./Animation"

const Opponent = () => {
  return (
    <motion.div 
         initial={"offscreen"}
         whileInView={"onscreen"}
         viewport={{once:true, amount:0.5}}
         transition={{staggerChildren:0.5}}
         className="flex flex-col items-center relative justify-center conquer xl:min-h-[500px] md:min-h-[300px] mid:min-h-[400px] pt-[100px] pb-[100px] ">
              <motion.p
               variants={textAnimate}
               className="text-white text-center text-[20px] font-Passion-One">
                 Welcome to the Islands, Challanger
              </motion.p>
              <motion.p 
               variants={textAnimate}
              className="text-white text-[18px] max-w-[70%] md:text-[30px] xl:text-[64px] xl:max-w-[900px] font-Passion-One text-center leading-[1.5]">
                Make your way through your opponents and conquer the Island
              </motion.p>
             <img src={LeafLeft} alt="button" className="absolute  left-[20px] mid:left-[100px] top-[100px]  overflow-hidden xl:overflow-visible h-[100px] sm:h-[200px] xl:h-[280px]"/>
             <img src={LeafRight} alt="button" className="absolute right-[20px] mid:right-[100px] top-[100px] ms:left-0 overflow-hidden xl:overflow-visible h-[100px] sm:h-[200px] xl:h-[280px]"/>
             <img src={Star} alt="button" className="absolute bottom-[50px] top-[auto] ms:left-0 overflow-hidden  w-[150px] sm:w-[200px] lg:w-[100] "/>
        </motion.div>
  )
}

export default Opponent