import React from 'react'
import  Fortrex from "assets/images/fortrex.svg";
import { ReactComponent as Join} from "assets/images/join.svg";
import { ReactComponent as Plays} from "assets/images/play.svg";
import { ReactComponent as GoogleIcon} from "assets/images/google.svg";
import { ReactComponent as AppIcon} from "assets/images/apple.svg";

import UserIcon from "assets/images/user.svg";
import SubIcon from "assets/images/Subtract.svg";

import {motion} from "framer-motion"
import { imageFade} from "./Animation"



function Hero() {
  return (
        <motion.div 
            initial={"offscreen"}
            whileInView={"onscreen"}
            viewport={{once:true, amount:0.5}}
            transition={{staggerChildren:1}}
            className="pd hero">
         <motion.div 
          initial={{ scale: 0.4 }}
          animate={{ scale: 1 }}
          transition={{ ease: [0.6, 0.01, -0.05, 0.95], duration: 2, delay: 1}}
          className="h-[160px] md:h-[380px] mt-[3rem] mid:mt-[1rem]">
          <img src={Fortrex} alt="logo" className="w-full h-full " />
         </motion.div>
         <motion.div 
           variants={imageFade}
          className="pd mt-5 flex flex-col items-center justify-center">
          <a
            className="text-white flex items-center justify-between text-mid uppercase py-[10px] px-[20px] rounded-lg font-Passion-One"
            href="http://battle.fortrexcolorduels.com/register"
          >
            <Join className="w-full h-full"/>
          </a>
          <a
            className="text-white flex items-center justify-between text-mid  uppercase py-[10px] px-[20px] rounded-lg font-Passion-One"
            href="http://battle.fortrexcolorduels.com/register"
          >
            <Plays className="w-full h-full"/>
          </a>
        </motion.div>

        <motion.div 
            variants={imageFade}
          className="pd mt-5 flex items-center justify-center gap-8">
          <a
            className="text-white md:w-[160px] md:h-[56px]  flex items-center justify-center btn text-mid uppercase py-[10px] px-[20px] rounded-lg font-Passion-One"
            href="http://battle.fortrexcolorduels.com/register"
          >
            <span className="flex items-center gap-2">
               <img src={UserIcon} alt="button" className="w-full h-full"/>
              Register
            </span> 
          </a>
          <a
            className="text-white md:w-[160px] md:h-[56px] flex items-center justify-center gap-2 btn text-mid uppercase py-[10px] px-[20px] rounded-lg font-Passion-One"
            href=""
          >
            <span className="flex items-center gap-2">
              <img src={SubIcon} alt="button" className="w-full h-full"/>
              Tutorial
            </span> 
          </a>
        </motion.div>

        <motion.div 
         variants={imageFade}
         className="pd flex items-center justify-center gap-8 mt-12">

          <a
            className=" flex items-center justify-center"
            href="#"
          >
            <AppIcon className="w-full h-full"/>
          </a>
          <a
            className=" flex items-center justify-center"
            href="#"
          >
            <GoogleIcon  className="w-full h-full"/>
          </a>
          </motion.div>
        </motion.div>
  )
}

export default Hero