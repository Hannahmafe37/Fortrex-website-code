/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import { ReactComponent as Logo } from "assets/images/logo.svg";
import { ReactComponent as Hamburger } from "assets/icons/hamburger.svg";
import { ReactComponent as Close } from "assets/icons/close.svg";
import { hideTopNav, showTopNav } from "utils/navigation";
import {motion} from "framer-motion"

const TopNav = () => {
  return (
    <motion.div 
    initial={"offscreen"}
    whileInView={"onscreen"}
    viewport={{once:false, amount:0.5}}
    transition={{staggerChildren:1}}
    className="flex items-center justify-between pt-[29px] lg:px-[80px] pd nav">
      <Logo />
      <ul className="p-0 items-center space-x-5 hidden mid:flex">
        <li>
          <a
            href="/"
            className="font-vectro-bold text-white uppercase text-[18px]"
          >
            Home
          </a>
        </li>
        <li>
          <a
            className="font-vectro-bold text-white uppercase text-[18px]"
            href="#About"
          >
            About
          </a>
        </li>
        <li>
          <a
            className="font-vectro-bold text-white uppercase text-[18px]"
            href="/#"
          >
            WhitePaper
          </a>
        </li>
        <li>
          <a
            className="font-vectro-bold text-white uppercase text-[18px]"
            href="#team"
          >
            Our Team
          </a>
        </li>
        <li>
          <a
            className="font-vectro-bold text-white uppercase text-[18px]"
            href="#roadmap"
          >
            ROADMAP
          </a>
        </li>
        <li>
          <a
            className="font-vectro-bold text-white uppercase text-[18px]"
            href="#play"
          >
            What is P$E?
          </a>
        </li>
        <li>
          <a
            className="font-vectro-bold text-white uppercase text-[18px]"
            href="#contact"
          >
            Contact
          </a>
        </li>
      </ul>
     
      <div
        className="mid:hidden cursor-pointer translate-y-[-5px]"
        onClick={showTopNav}
      >
        <Hamburger />
      </div>
      <div
        className="hidden fixed top-0 h-screen w-screen bg-[#16122A] left-0 z-[1000] duration-100 transition-all"
        id="mini-topnav"
      >
        <div className="flex items-center justify-between mt-5 mb-[100px] px-5">
          <Logo />
          <div className="cursor-pointer" onClick={hideTopNav}>
            <Close className="h-[30px] w-[30px]" />
          </div>
        </div>
        <ul className="flex flex-col space-y-[20px] justify-center items-center">
          <li>
            <a
              className="font-vectro-bold text-white uppercase text-[24px]"
              href="/"
              onClick={hideTopNav}
            >
               Home
            </a>
          </li>
          <li>
            <a
              className="font-vectro-bold text-white uppercase text-[24px]"
              href="/about"
              onClick={hideTopNav}
            >
              About
            </a>
          </li>
          <li>
            <a
              className="font-vectro-bold text-white uppercase text-[24px]"
              href="#"
              onClick={hideTopNav}
            >
              WhitePaper
            </a>
          </li>
          <li>
            <a
              className="font-vectro-bold text-white uppercase text-[24px]"
              href="#team"
              onClick={hideTopNav}
            >
              Our team
            </a>
          </li>
          <li>
            <a
              className="font-vectro-bold text-white uppercase text-[24px]"
              href="#play"
              onClick={hideTopNav}
            >
             What is P&E?
            </a>
          </li>
          <li>
            <a
              className="font-vectro-bold text-white uppercase text-[24px]"
              href="#contact"
              onClick={hideTopNav}
            >
             Contact
            </a>
          </li>
          
        </ul>
      </div>
    </motion.div>
  );
};

export default TopNav;
