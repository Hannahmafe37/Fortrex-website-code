import React from "react";
import logo from "../../../assets/images/duel.svg";
import twitter from "../../../assets/images/twitter.svg";
import facebook from "../../../assets/images/facebook.svg";
import instagram from "../../../assets/images/ig.svg";
import discord from "../../../assets/images/discord.svg";
import telegram from "../../../assets/images/telegram.svg";
import {motion} from "framer-motion"
import {textAnimate} from "./Animation"

export default function Footer() {

  const socialLink = [
    {
      social: twitter,
      link: ""
    },
    {
      social: telegram,
      link: ""
    },
    {
      social: discord,
      link: ""
    },
    {
      social: facebook,
      link: ""
    },
    {
      social: instagram,
      link: ""
    },
  ];
  return (
    <>
    <footer className="mt-[3rem] mid:mt-[5rem]" id="contact">
      <div
        className="container max-w-[1200px] m-[auto] py-[3rem]">
       <motion.div 
          initial={"offscreen"}
          whileInView={"onscreen"}
          viewport={{once:true, amount:0.5}}
          transition={{staggerChildren:0.5}}
          className="upper flex justify-between">
         <motion.img 
           variants={textAnimate}
            src={logo} alt='logo' className="basis-3/12 max-w-[300px]"/>
         <motion.div 
           variants={textAnimate}
           className="flex flex-col">
          <form >
            <label className="font-Passion-One text-white text-2xl ">Newsletter subscription</label>
            <div className="flex input-container mt-4">
             <input type='email' placeholder="Your email address" className="bg-black text-white p-1"/>
             <button type='submit' className="submit-btn">Submit</button>
            </div>
            <ul className="flex flex-col gap-4 mt-[2rem]">
              <h3 className="font-Passion-One text-white text-2xl">Social</h3>
              <div className="flex gap-4" >
               {socialLink.map((icon, index) => (
                  <a href={icon.link} target='_blank' rel="noreferrer" key={index}><img src={icon.social} key={index} alt='social-icon'/></a>
                ))}
              </div>
           </ul>
          </form>
         </motion.div>
         <motion.div 
            variants={textAnimate}
            className="links">
              <div className="link flex flex-col gap-4">
                 <h3 className="font-Passion-One text-white text-2xl">Contact Info</h3>
                <ul className="flex flex-col gap-4">
                  <a href="mailto:admin@fortrexcolorduel.com" className=" text-white" ><li >admin@fortrexcolorduel.com</li></a>
                  <a href="mailto:support@fortrexcolorduel.com" className=" text-white" ><li >support@fortrexcolorduel.com</li></a>
                  <a href="tel:+10249592034825" className=" text-white" ><li >+10249592034825</li></a>
               
                </ul>
              </div>
          </motion.div>
        </motion.div>
        
      </div>
    </footer>
    <div className="lower text-center text-white">
     <p>© Copyright by <span className="text-[#226ADD]">Fortrex Color Duel</span> All rights reserved.</p>
    </div>
  </>
  );
}
