import React from 'react'
import  Magg  from "assets/images/magg.svg";
import {motion} from "framer-motion"
import {textAnimate,  imageAnimate} from "./Animation"

function Play() {
  return (     
    <motion.div 
        initial={"offscreen"}
        whileInView={"onscreen"}
        viewport={{once:true, amount:0.5}}
        transition={{staggerChildren:0.5}}
        className="flex space-x-2 mt-[5%] items-center justify-center magg-container p-[1rem]" 
        id="play">
       <div className="flex-shrink-0">
        <motion.h1 
        variants={textAnimate}
        className="text-white text-center text-[30px] mid:text-[64px] sm:text-start leading-none">
        Play & Earn
        </motion.h1>
        <motion.p 
        variants={textAnimate} 
        className="leading-8 mt-[33px] font-zona-semibold text-white text-[16px] mid:text-[18px] max-w-[533px]">
        Fortrex: Color Duels is an RTS game where players can earn COL 
        token through their battles. While battling their way up to the conquest, 
        players can unlock different Fortrexes, customize their talents to your 
        playstyle. As you grow and challange harder foes, you will earn more COL 
        tokens, NFTs and more rewards.
        </motion.p>
     </div>
      <motion.div 
        variants={imageAnimate} 
       className=" pointer-events-none max-h-[800px] max-w-[675px]">
        <img src={Magg} className="max-h-[750px] mid:max-h-[1000px]"/>
      </motion.div>
  </motion.div>
  )
}

export default Play